<?php if (isset($component)) { $__componentOriginal0fe988a0827f96795dcdcc142084dbb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0fe988a0827f96795dcdcc142084dbb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.frontend.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.frontend.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    hello resources page
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0fe988a0827f96795dcdcc142084dbb0)): ?>
<?php $attributes = $__attributesOriginal0fe988a0827f96795dcdcc142084dbb0; ?>
<?php unset($__attributesOriginal0fe988a0827f96795dcdcc142084dbb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0fe988a0827f96795dcdcc142084dbb0)): ?>
<?php $component = $__componentOriginal0fe988a0827f96795dcdcc142084dbb0; ?>
<?php unset($__componentOriginal0fe988a0827f96795dcdcc142084dbb0); ?>
<?php endif; ?><?php /**PATH /var/www/html/cyber-club-site/resources/views/resources.blade.php ENDPATH**/ ?>