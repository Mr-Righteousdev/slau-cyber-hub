<x-layouts.frontend.app>
    hello resources page
</x-layouts.frontend.app>